//  TradingView禁用的指标
/* eslint-disable */ 
let studies_access = { // 设置内置指标的对象
  type: 'black', // black(所有列出的项目会被禁用)
  tools: [
    {
      name: 'Spread' // 搜索商品
    },
    {
      name: 'Ratio' // 搜索商品
    },
    { name: 'SMI Ergodic Indicator/Oscillator' },
    { name: 'Ichimoku Cloud' },
    { name: 'Triple EMA' },
    { name: 'TRIX' },
    { name: 'Zig Zag' },
    { name: 'Price Oscillator' },
    { name: 'Price Channel' },
    { name: 'Price Volume Trend' },
    { name: 'Coppock Curve' },
    { name: 'Klinger Oscillator' },
    { name: 'Net Volume' },
    { name: 'Moving Average Weighted' },
    { name: 'Momentum' },
    { name: 'Awesome Oscillator' },
    { name: 'Envelope' },
    { name: 'Double EMA' },
    { name: 'Rate Of Change' },
    { name: 'Balance of Power' },
    { name: 'Williams Fractal' },
    { name: 'Williams %R' },
    { name: 'Bollinger Bands %B' },
    { name: 'Bollinger Bands Width' },
    { name: 'Average Directional Index' },
    { name: 'Smoothed Moving Average' },
    { name: 'CRSI' },
    { name: 'VWAP' },
    { name: 'VWMA' },
    { name: 'Volume Oscillator' },
    { name: 'Moving Average Exponential' },
    { name: 'ASI' },
    { name: 'Vortex Indicator' },
    { name: 'Least Squares Moving Average' },
    { name: 'Mass Index' },
    { name: 'Chop Zone' },
    { name: 'Choppiness Index' },
    { name: 'Advance/Decline' },
    { name: 'Correlation Coefficient' },
    { name: 'Relative Volatility Index' },
    { name: 'Relative Vigor Index' },
    { name: 'Average True Range' },
    { name: 'Ease Of Movement' },
    { name: 'Accumulation/Distribution' },
    { name: 'Linear Regression Curve' },
    { name: 'Ultimate Oscillator' },
    { name: 'On Balance Volume' },
    { name: 'Hull Moving Average' },
    { name: "Elder's Force Index" },
    { name: 'Chaikin Money Flow' },
    { name: 'Chaikin Oscillator' },
    { name: 'Fisher Transform' },
    { name: 'Money Flow' },
    { name: 'Pivot Points Standard' },
    { name: 'McGinley Dynamic' },
    { name: 'Chande Kroll Stop' },
    { name: 'Chande Momentum Oscillator' },
    { name: 'Arnaud Legoux Moving Average' },
    { name: 'Aroon' },
    { name: 'Stochastic' },
    { name: 'Detrended Price Oscillator' },
    { name: 'Know Sure Thing' },
    { name: 'Historical Volatility' },
    { name: 'Commodity Channel Index' },
    { name: 'Connors RSI' },
    { name: 'Accumulative Swing Index' }
  ]
}

//  TradingView 初始化时 的指标
export let indexBtnList = [
  {
    name: 'MA',
    active: true,
    tvIndexList: {
      MA5: null,
      MA10: null,
      MA30: null
    },
    argsList: [
      {
        lineName: 'MA5',
        input: [5],
        name: 'Moving Average',
        style: {
          'Plot.color': 'rgb(255,193,37)'
          // "Plot.linewidth": 4
        }
      },
      {
        lineName: 'MA10',
        input: [10],
        name: 'Moving Average',
        style: {
          'Plot.color': 'rgb(99,184,255)'
          // "Plot.linewidth": 4
        }
      },
      {
        lineName: 'MA30',
        input: [30],
        name: 'Moving Average',
        style: {
          'Plot.color': 'rgb(125,38,205)'
          // "Plot.linewidth": 4
        }
      }
    ]
  },
  {
    name: 'BOLL',
    active: false,
    tvIndex: null,
    args: {
      name: 'Bollinger Bands',
      input: [26, 2],
      style: {
        'Upper.color': 'rgba(255,193,37,0.7)',
        'Lower.color': 'rgba(125,38,205,0.7)',
        'Plots Background.color': 'rgba(99,184,255,0)',
        'Basis.color': 'rgba(99,184,255,0.7)'
        // "Upper.linewidth": 4,
        // "Lower.linewidth": 4,
        // "Basis.linewidth": 4
        // "bollinger bands.linewidth":4
      }
    }
  },
  {
    name: 'VOL',
    active: true,
    tvIndex: null,
    args: {
      name: 'Volume',
      input: [0, 20],
      style: {
        // "Growing":"",
      }
    }
  },
  {
    name: 'MACD',
    active: false,
    tvIndex: null,
    args: {
      name: 'MACD',
      input: [12, 26, 'close', 9],
      style: {
        'Histogram.color': 'rgb(253,0,102)',
        'MACD.color': 'rgb(32,139,251)',
        'Signal.color': 'rgb(252,96,30)'
      }
    }
  },
  // {
  //   name: "KDJ",
  //   active: false,
  //   tvIndex: null,
  //   args: {
  //     name: "KDJ Indicator",
  //     input: [9, 3],
  //     style: {}
  //   }
  // },
  {
    name: 'RSI',
    active: false,
    tvIndex: null,
    args: {
      name: 'Stochastic RSI',
      style: {},
      input: [9, 3, 3]
    }
  }
]

// TradingView 的默认参数
export const tradeViewOptions = {
  debug: false,
  fullscreen: true,
  autosize: true,
  // symbol: this.symbol, // 商品标识
  container_id: 'tv_chart_container',
  datafeed: null,
  library_path: '../../static/charting_library/',
  locale: 'zh',
  timezone: 'Asia/Shanghai',
  custom_css_url: '../../css/mycss.css',
  drawings_access: {
    type: 'black',
    tools: [{ name: 'Regression Trend' }]
  },
  enabled_features: [
    //   'disable_resolution_rebuild',
    'caption_buttons_text_if_possible',

    'hide_last_na_study_output', // 隐藏指标后面的 n/a
    'dont_show_boolean_study_arguments' // 不显示指标后面的布尔值
  ],
  disabled_features: [
    // 禁用功能（隐藏图标按钮）数组  https://tradingview.gitee.io/featuresets/
    'use_localstorage_for_settings',
    'left_toolbar',
    'header_resolutions',
    'header_compare',
    'header_settings',
    'header_screenshot',
    'timeframes_toolbar',
    'dont_show_boolean_study_arguments',
    // 'hide_last_na_study_output',
    'symbol_info',
    'display_market_status',
    'legend_context_menu',
    'show_logo_on_all_charts',
    'adaptive_logo',
    'move_logo_to_main_pan',
    'property_pages',
    'header_symbol_search',
    'header_interval_dialog_button',
    'show_interval_dialog_on_key_press',
    'symbol_search_hot_key',
    'study_dialog_search_control',
    'symbol_info',
    'main_series_scale_menu',
    'star_some_intervals_by_default',
    'datasource_copypaste',
    'right_bar_stays_on_scroll',
    'context_menus',
    'go_to_date',
    'compare_symbol',
    'border_around_the_chart',
    'timezone_menu',
    'control_bar', // todo: przetestowac
    // 'edit_buttons_in_legend', // todo: przetestowac
    'remove_library_container_border',
    'volume_force_overlay',
    'widget_logo',
    'left_toolbar',
    'pane_context_menu'

  ],
  overrides: {
    // 覆盖操作
    'mainSeriesProperties.candleStyle.upColor': '#EF4034',
    'mainSeriesProperties.candleStyle.downColor': '#1DB270',
    'mainSeriesProperties.candleStyle.drawWick': true,
    'mainSeriesProperties.candleStyle.drawBorder': true,
    'mainSeriesProperties.candleStyle.borderColor': '#378658',
    'mainSeriesProperties.candleStyle.borderUpColor': '#EF4034',
    'mainSeriesProperties.candleStyle.borderDownColor': '#1DB270',
    'mainSeriesProperties.candleStyle.wickUpColor': '#EF4034',
    'mainSeriesProperties.candleStyle.wickDownColor': '#1DB270',
    'mainSeriesProperties.candleStyle.barColorsOnPrevClose': false
  },
  studies_overrides: {
    // 柱状图颜色
    'volume.volume.color.0': 'rgba(29, 178, 112,1)',
    'volume.volume.color.1': 'rgba(239, 64, 52, 1)'
  },
  // 格式化显示日期和时间的值
  customFormatters: {
    timeFormatter: {
      format: function (date) {
        function one2two (val) {
          return val < 10 ? '0' + val : val
        }
        // eslint-disable-next-line camelcase
        let _format_str = '%h:%m'
        return _format_str
          .replace('%h', one2two(date.getUTCHours()), 2)
          .replace('%m', one2two(date.getUTCMinutes()), 2)
      }
    },
    dateFormatter: {
      format: function (date) {
        function one2two (val) {
          return val < 10 ? '0' + val : val
        }
        return (
          date.getUTCFullYear() +
                '/' +
                one2two(date.getUTCMonth() + 1) +
                '/' +
                one2two(date.getUTCDate())
        )
      }
    }
  }
}

// Au(T+D) Ag(T+D) mAu(T+D) 合约详情
export const instIDInfo = {
  'Au(T+D)': {
    prod_code: 'Au(T+D)', // 产品代码
    prod_name: '黄金延期', // 交易品种
    market_id: '延期市场', // 交易方式
    measure_unit: '1000', // 交易单位
    tradeUnit: '1000克/手', // 交易单位
    priceUnit: '元/克', // 报价单位
    priceChangeUnit: '0.01元/克', // 最小变动价位
    min_hand: '1', // 最小单笔报价量
    max_hand: '200' // 最大单笔报价量
  },
  'Ag(T+D)': {
    prod_code: 'Ag(T+D)',
    prod_name: '白银延期',
    market_id: '延期市场',
    measure_unit: '1000',
    tradeUnit: '1千克/手', // 交易单位
    priceUnit: '元/千克', // 报价单位
    priceChangeUnit: '1元/千克', // 最小变动价位
    min_hand: '1',
    max_hand: '10000'
  },
  'mAu(T+D)': {
    prod_code: 'mAu(T+D)',
    prod_name: 'Mini黄金延期',
    market_id: '延期市场',
    measure_unit: '100',
    tradeUnit: '100克/手', // 交易单位
    priceUnit: '元/克', // 报价单位
    priceChangeUnit: '0.01元/克', // 最小变动价位
    min_hand: '1',
    max_hand: '2000'
  }
}
