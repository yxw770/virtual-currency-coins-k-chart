<template>

  <div class="tv_chart">
    <button @click="changeChart('Au(T+D)','DK')">日K</button>
    <button @click="changeChart('Au(T+D)','WK')">周K</button>
    <button @click="changeChart('Au(T+D)','MK')">月K</button>
    <button @click="changeChart('Au(T+D)','mk01')">1分钟</button>
    <button @click="changeChart('Au(T+D)','mk05')">5分钟</button>
    <button @click="changeChart('Au(T+D)','mk15')">15分钟</button>
    <button @click="changeChart('Au(T+D)','mk30')">30分钟</button>
    <button @click="changeChart('Au(T+D)','mk60')">60分钟</button>
    <button @click="changeChart('Au(T+D)','mk120')">120分钟</button>
    <button @click="changeChart('Au(T+D)','mk240')">240分钟</button>
 <button @click="resetData()">resetData</button>
    <!-- <div class="tab-box">
      <tab v-model="selData">
        <tab-item id="time" @click.native="changeChart('time')">分时</tab-item>
        <tab-item id="DK" @click.native="changeChart('DK')">日K</tab-item>
        <tab-item id="WK" @click.native="changeChart('WK')">周K</tab-item>
        <tab-item id="MK" @click.native="changeChart('MK')">月K</tab-item>
      <tab-item
            id="mk"
            @click.native="changeChart('mk')"
        >{{mkName}}</tab-item>
    </tab>-->
    <!-- 分钟k线选项 -->
    <!-- <transition name="down">
          <ul
            v-show="isShowMinuteBox"
            class="minute-box"
            ref="minuteBox"
          >
            <li
              :class="{'active':chartType=='mk60'}"
              @click="changeChart('mk60')"
            >60分</li>
            <li
              :class="{'active':chartType=='mk30'}"
              @click="changeChart('mk30')"
            >30分</li>
            <li
              :class="{'active':chartType=='mk15'}"
              @click="changeChart('mk15')"
            >15分</li>
            <li
              :class="{'active':chartType=='mk05'}"
              @click="changeChart('mk05')"
            >5分</li>
            <li
              :class="{'active':chartType=='mk01'}"
              @click="changeChart('mk01')"
            >1分</li>
          </ul>
        </transition>
        <i class="corn"></i>
        <transition name="fold">
          <div
            @click="isShowMinuteBox=false"
            v-show="isShowMinuteBox"
            class="minute-mask"
            ref="minuteMask"
          ></div>
    </transition>-->
    <div id="tv_chart_container" class="tv_chart_container"></div>
  </div>
</template>
<script>
/* eslint-disable  */
// 绿色
//  tradingview 的 Datafeeds
import Datafeeds from './Datafeeds'
// 加载tradingview 相关的配置
import { tradeViewOptions, indexBtnList, instIDInfo } from './config'; let red = '#EF4034' // 红色
let green = '#1DB270'

export default {
  name: 'quotationDetails',
  components: {},
  props: {},
  data () {
    return {
      datafeeds: null, // tradingview 的 Datafeeds 实例
      timeShareTimer: null, // 分时计时器
      priceList: [], // k线数据,
      mkName: '分钟',
      chartType: 'time',
      isShowMinuteBox: false,
      timeShareChart: null,
      currentInstID: 'Au(T+D)',
      selData: 'MK',
      selData2: '5speed',
      currentIndex: 0,
      quotation: {
        //   title: '黄金延期',
        //   instID: 'Au(T+D)'
      },
      goodInfo: null
    }
  },
  computed: {},
  mounted () {
    this.changeChart(this.currentInstID, this.selData)
  },
  methods: {
    changeChart (instID, type) {
      
      console.log(instIDInfo, instID, instIDInfo[instID])
      this.quotation.title = instIDInfo[instID].prod_name
      this.quotation.instID = instIDInfo[instID].prod_code

      // 赋值k线类型
      this.chartType = type

      // k线相关的逻辑
      let intervalList = {
        DK: '1D',
        WK: '1W',
        MK: '1M',
        mk240: 240,
        mk120: 120,
        mk60: 60,
        mk30: 30,
        mk15: 15,
        mk05: 5,
        mk01: 1
      }

      if (type.indexOf('mk') != -1) {
        this.mkName = intervalList[type] + '分'
      } else {
        this.mkName = '分钟'
      }
      this.drawKLineChart({
        name: this.quotation.title,
        ticker: this.quotation.instID,
        description: this.quotation.title,
        interval: intervalList[type]
      })
    },
    resetData () {
      this.widget.chart().resetData()
    },
    drawKLineChart (goodsInfo) {
      this.datafeeds = new Datafeeds(goodsInfo, this)
      let options = Object.assign({}, tradeViewOptions, {
        symbol: goodsInfo.ticker, // 商品标识
        width: '100%',
        height: 350,
        interval: goodsInfo.interval,
        datafeed: this.datafeeds
      })
      // eslint-disable-next-line new-cap
      this.widget = new TradingView.widget(options);
      //  this.widget = this.widget.activeChart()
      // 当图表初始化并准备就绪时  设置指标
      this.widget.onChartReady(() => {
        //  给所有的分钟k 设置动态添加数据
        // if (this.num == 5) {
        //   let startTime = 0;
        //   this.reqKLineTimer = setInterval(() => {
        //     startTime += 1000;
        //     if (startTime % this.timerInterval == 0) {
        //       this.datafeeds.barsUpdater.getBars(this.currentInst_id);
        //     } else {
        //       let newClose = this.dataList2[this.currentIndex].last * 1;
        //       if (newClose) {
        //         this.datafeeds.barsUpdater.updateData(
        //           this.currentInst_id,
        //           newClose
        //         );
        //       }
        //     }
        //   }, 1000);
        // }
        // init  index ===>  MA
        let MAIndex = indexBtnList.find(e => e.name === 'MA')
        for (let i = 0; i < MAIndex.argsList.length; i++) {
          const _index = MAIndex.argsList[i]
          MAIndex.tvIndexList[_index.lineName] = this.widget
            .chart()
            .createStudy(
              _index.name,
              false,
              false,
              _index.input,
              null,
              _index.style
            )
        }
        // init index ==> volume
        let VOLIndex = indexBtnList.find(e => e.name === 'VOL')
        VOLIndex.tvIndex = this.widget
          .chart()
          .createStudy(
            VOLIndex.args.name,
            false,
            false,
            VOLIndex.args.input,
            null,
            VOLIndex.args.style
          )

        // 获取主视图的 高开低收
        // let timer = setInterval(() => {
        //   if (this.getTVOCHL()) {
        //     clearInterval(timer);
        //   }
        // }, 10);
        // 在组件销毁时 去除setInterval定时器
        this.$on('hook:beforeDestroy', function () {
          clearInterval(timer)
        })
        // 创建自定义按钮
        this.widget.headerReady().then(() => {
          //   var button = this.widget.createButton({ align: 'right' });
          //   button.addEventListener('click', () => {
          //     let query = Object.assign({}, this.$route.query, goodsInfo, {
          //       instID: goodsInfo.ticker,
          //       chartType: this.chartType,
          //       selData: this.selData
          //     });
          //     this.$router.push({ path: '/quotation_kline', query: query });
          //   });
          //   button.textContent = '全屏';
        })

        // this.widget.subscribe('mouse_up', e => {
        //   // console.log("mouse_up");
        //   // 获取主视图的 高开低收
        //   this.getTVOCHL();
        // });
        // this.widget.subscribe("drawing", e => {
        //   console.log("drawing");
        // });
        this.widget.subscribe('study', e => {
          // console.log(
          //   "指标将添加到图表中。参数包含一个带有 value 字段的对象，该字段与指标名称相对应。"
          // );
          // console.log(e);
          this.widget.closePopupsAndDialogs()
        })
        // 最新k线被更新
        // this.widget.subscribe('onTick', e => {
        //   // console.log("onTick");
        //   this.getTVOCHL();
        // });
      })
    },
    
  }
}
</script>

<style lang="less" scoped>
.price-info-wrap {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #ffffff;
  padding: 0.08rem 0.1rem 0.14rem 0.32rem;
  .price-box {
    .price {
      height: 0.77rem;
      font-size: 0.64rem;
      font-family: UDC-Bold;
      font-weight: bold;
      line-height: 0.77rem;
    }
    .tips {
      display: flex;
      height: 0.33rem;
      font-size: 0.24rem;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      line-height: 0.33rem;
      span:last-child {
        margin-left: 0.16rem;
      }
    }
  }
  .other-info {
    .row {
      display: flex;
      height: 0.33rem;
      font-size: 0.24rem;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: rgba(153, 153, 153, 1);
      line-height: 0.33rem;
      // &:first-child {
      //   margin-top: 0.15rem;
      // }
      // &:last-child {
      margin-top: 0.17rem;
      // }
      span {
        margin-right: 0.17rem;
        &.w-180 {
          width: 1.8rem;
        }
        &.w-140 {
          width: 1.4rem;
        }
        i {
          color: #333333;
        }
      }
    }
  }
}

.data-wrap {
  margin-top: 0.1rem;
  padding-bottom: 0.26rem;
  background: #ffffff;
  .tab-box {
    position: relative;
    .minute-box {
      position: absolute;
      right: 0;
      width: 100%;
      z-index: 10;
      background: #ffffff;
      box-shadow: 0px 0.02rem 0.06rem 0.01rem rgba(0, 0, 0, 0.15);
      height: 1.5rem;
      line-height: 1.5rem;
      bottom: -1.45rem;
      display: flex;
      justify-content: space-between;
      padding: 0 0.28rem;
      overflow: hidden;
      &.down-enter-active,
      &.down-leave-active {
        transition: all 0.5s;
      }
      &.down-enter,
      &.down-leave-active {
        bottom: 0;
        height: 0;
      }
      li {
        display: inline-block;
        font-size: 0.26rem;
        text-align: center;
        border-bottom: 1px solid #e8e8e8;
        color: #666666;
        width: 1.12rem;
        height: 0.72rem;
        border: 1px solid #dddddd;
        line-height: 0.72rem;
        align-self: center;
        border-radius: 0.05rem;
        &.active {
          border: 1px solid #4d7bfe;
          color: #4d7bfe;
        }
      }
    }
    .minute-mask {
      position: fixed;
      left: 0;
      bottom: 0;
      z-index: 5;
      width: 100%;
      background: rgba(0, 0, 0, 0.5);
      backdrop-filter: blur(0.2rem);
      opacity: 1;
      &.fold-enter-active,
      &.fold-leave-active {
        transition: all 0.5s;
      }
      &.fold-enter,
      &.fold-leave-active {
        opacity: 0;
      }
    }
  }
  .time-share-wrap {
    padding-top: 0.11rem;
    display: flex;
    justify-content: space-between;
    .chart-box {
      width: 4.65rem;
      canvas {
        width: 4.65rem;
        height: 7.2rem;
      }
    }
    .other-data-wrap {
      width: 2.43rem;
      margin-right: 0.13rem;
      .speed-row {
        display: flex;
        // justify-content: space-around;
        margin-top: 0.31rem;
        height: 0.33rem;
        font-size: 0.24rem;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: rgba(51, 51, 51, 1);
        line-height: 0.33rem;
        &:first-child {
          margin-top: 0.1rem;
        }
        &.m-t-20 {
          margin-top: 0.2rem !important;
        }
        span {
          flex: 1;
        }
      }
      .detailed-wrap {
        height: 6.1rem;
        padding-top: 0.2rem;
        overflow: auto;
        .detailed-row {
          display: flex;
          justify-content: space-around;
          margin-bottom: 0.25rem;
          height: 0.33rem;
          font-size: 0.24rem;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: rgba(51, 51, 51, 1);
          line-height: 0.33rem;
          span {
            flex: 1;
          }
        }
      }
    }
  }
  .k-data-wrap {
    padding-top: 0.11rem;
    .chart-box {
      // height: 6rem;
      .price-list {
        margin: 0 auto;
        display: flex;
        height: 0.4rem;
        line-height: 0.4rem;
        font-size: 0.24rem;
        text-align: left;
        color: #333333;
        background: #fff;
        text-align: center;
        .price-item {
          flex: 1;
        }
      }
    }
  }
}

.footer-wrap {
  display: flex;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  .btn {
    background: #ffffff;
    height: 1rem;
    text-align: center;
    line-height: 1rem;
    font-size: 0.36rem;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: rgba(188, 148, 88, 1);
    &.info-btn {
      width: 3rem;
    }
    &.trade-btn {
      width: 4.5rem;
      background-color: #d7af74;
      color: #ffffff;
    }
  }
}
.tv_chart_container {
  width:100%;
  height: 400px; /* no */
}

.mybutton {
  height: 60px;
  width: 160px;
}
</style>

// WEBPACK FOOTER //
// src/views/quotation/details.vue
