
// import datas from './data'
/* eslint-disable  */
/**
 * 数据更新器
 * 通过更新器触发datafeeds的getBars实时更新图表数据
 */
class dataUpdater {
  constructor (datafeeds, vm) {
    this.page = 0; // 页数
    this.subscribers = {}; // 订阅者对象
    this.lastBars = {}; // 最后一条数据
    this.vm = vm;
  
  }
  // 添加   订阅K线数据
  subscribeBars (symbolInfo, resolution, newDataCallback, listenerGuid) {
    this.subscribers[symbolInfo.ticker] = {
      listener: newDataCallback, // 回调函数
      resolution: resolution, // 分辨率
      symbolInfo: symbolInfo // 商品信息
    };
  }
  // 取消   订阅K线数据
  unsubscribeBars (listenerGuid) {
    delete this.subscribers[listenerGuid];
  }
  // 更新数据
  updateData (instID, newClose) {
    if (this.lastBars.time) {
      this.lastBars.close = newClose * 1;
      let subscribers = this.subscribers[instID];
      if (subscribers && subscribers.listener) {
        subscribers.listener(this.lastBars);
      }
    }
  }
  getAllBars (
    symbolInfo,
    resolution,
    startDate,
    endDate,
    onDataCallback,
    onErrorCallback,
    isFirst
  ) {
    if (isFirst) {
      this.lastBars = {};
    }
    let typeLists = {
      '1D': 'day',
      '1W': 'week',
      '1M': 'month',
      '240': 'mk240',
      '120': 'mk120',
      '60': 'mk60',
      '30': 'mk30',
      '15': 'mk15',
      '5': 'mk05',
      '1': 'mk01'
    };
    let instID = symbolInfo.ticker;
    let type = typeLists[symbolInfo.interval];
    if (!isFirst) {
      this.page++;
    }
 

    if (!isFirst) {
      onDataCallback([], { noData: true });
    }else{
      
      let kLine=this.fmtData()
      onDataCallback(kLine, { noData: false });
      
    }
   
  
  }
  /**
   * 格式化和创建模拟 数据
   * @param {} list
   */
  fmtData ( ) {
    let list=[];
     for(let i=0;i<100000;i++){
      let time = new Date();
      if(list[i-1]){
        time.setDate(list[i-1].date.getDate()+1)
      }
      list.push({
        time: time.getTime(),
        close: 40 + Math.random() * 5,
        open: 40 + Math.random() * 5,
        high: 40 + Math.random() * 5,
        low: 40 + Math.random() * 5,
        volume: 100000 * Math.random(),
        date:time,
     
      });
     }
    return  list;
  }
}

export default dataUpdater;
