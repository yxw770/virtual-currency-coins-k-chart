
// 商品交易时间配置
/* eslint-disable  */
export default {
  // 上海金
  'Au(T+D)': {
    session: '2000-0230,0900-1530', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  'Ag(T+D)': {
    session: '2000-0230,0900-1530', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  'mAu(T+D)': {
    session: '2000-0230,0900-1530', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  'Au100g': {
    session: '2000-0230,0900-1530', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  'Au99.99': {
    session: '2000-0230,0900-1530', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },

  // 伦敦金  银  铂金  07:00~07:00
  '5120': { // 伦敦金
    session: '0700-0700', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  '5121': { // 伦敦银
    session: '0700-0700', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  '5122': { // 伦敦铂金
    session: '0700-0700', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },

  'USD': {
    session: '0600-0600', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  'USDRMB': {
    session: '0600-0600', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  'USDCNH': {
    session: '0600-0600', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },

  'CONC': {
    session: '0700-0600', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },

  '2A01': {
    session: '0930-1500', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  },
  '1A0001': {
    session: '0700-0700', // 商品交易时间
    timezone: 'Asia/Shanghai' //  商品的交易所时区
  }
}


