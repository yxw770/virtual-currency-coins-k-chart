
import dataUpdater from './dataUpdater'
import config from './config'
/* eslint-disable  */
/**
 * JS API
 */
class datafeeds {

    /**
     * JS API
     * @param {*Object} vue vue实例
     */
    constructor (goodsInfo, vm) {
        this.goodsInfo = goodsInfo;
        // eslint-disable-next-line new-cap
        this.barsUpdater = new dataUpdater(this, vm);
    }
    /**
     * @param {*Function} callback  回调函数
     * `onReady` should return result asynchronously.
     */
    // 提供填充配置数据的对象 ==> 设置 配置数据
    onReady (callback) {
        return new Promise((resolve, reject) => {
            let configuration = this.defaultConfiguration()
            resolve(configuration)
        }).then(data => callback(data))
    }
    /**
     * @param {*String} symbolName  商品名称或ticker
     * @param {*Function} onSymbolResolvedCallback 成功回调
     * @param {*Function} onResolveErrorCallback   失败回调
     * `resolveSymbol` should return result asynchronously.
     */
    // 通过商品名称解析商品信息
    resolveSymbol (symbolName, onSymbolResolvedCallback, onResolveErrorCallback) {
        return new Promise((resolve, reject) => {
            let symbolInfo = this.defaultSymbol()
            if (this.goodsInfo) {
                symbolInfo = Object.assign(this.defaultSymbol(), this.goodsInfo, config[this.goodsInfo.ticker])
            }
            resolve(symbolInfo)
        }).then(data => onSymbolResolvedCallback(data)).catch(err => onResolveErrorCallback(err))
    }

    /**
     * @param {*Object} symbolInfo  商品信息对象
     * @param {*String} resolution  分辨率  ==> 周期类型
     * @param {*Number} rangeStartDate  时间戳、最左边请求的K线时间
     * @param {*Number} rangeEndDate  时间戳、最右边请求的K线时间
     * @param {*Function} onDataCallback  回调函数
     * @param {*Function} onErrorCallback  回调函数
     */
    // 通过日期范围获取历史K线数据   ==》  获取k线数据
    getBars (symbolInfo, resolution, rangeStartDate, rangeEndDate, onDataCallback, onErrorCallback, isFirst) {
        this.barsUpdater.getAllBars(symbolInfo, resolution, rangeStartDate, rangeEndDate, onDataCallback, onErrorCallback, isFirst);
    }

    /**
     * 订阅K线数据。图表库将调用onRealtimeCallback方法以更新实时数据
     * @param {*Object} symbolInfo 商品信息
     * @param {*String} resolution 分辨率
     * @param {*Function} onRealtimeCallback 回调函数
     * @param {*String} subscriberUID 监听的唯一标识符
     * @param {*Function} onResetCacheNeededCallback (从1.7开始): 将在bars数据发生变化时执行
     */
    // 订阅K线数据
    subscribeBars (symbolInfo, resolution, onRealtimeCallback, subscriberUID, onResetCacheNeededCallback) {
        this.barsUpdater.subscribeBars(symbolInfo, resolution, onRealtimeCallback, subscriberUID, onResetCacheNeededCallback)
    }

    /**
     * 取消订阅K线数据
     * @param {*String} subscriberUID 监听的唯一标识符
     */
    // 取消订阅K线数据
    unsubscribeBars (subscriberUID) {
        this.barsUpdater.unsubscribeBars(subscriberUID)
    }
    /**
     * 默认配置
     */
    // method 的默认配置项
    defaultConfiguration () {
        return {
            supports_search: false, // 搜索
            supports_group_request: false,
            // 一个表示服务器支持的周期数组，周期可以是数字或字符串
            supported_resolutions: ['1', '5', '15', '30', '60', '1D', '1W', '1M'], // 周期选择器
            // 布尔值来标识您的 datafeed 是否支持在K线上显示标记。
            supports_marks: false,
            // 布尔值来标识您的 datafeed 是否支持时间刻度标记。
            supports_timescale_marks: true,
            // 将此设置为true假如您的datafeed提供服务器时间（unix时间）
            supports_time: true
        }
    }

    /**
     * 默认商品信息  ==》 商品信息结构
     */
    defaultSymbol () {
        return {
            // name: '黄金延期', // 商品名称
            // ticker: 'Au(T+D)',// 唯一标识符
            // description: '黄金延期',// 商品说明
            session: '2000-0230,0900-1530', // 商品交易时间
            timezone: 'Asia/Shanghai', //  商品的交易所时区
            minmov: 1, // 最小波动
            minmov2: 0, //
            pricescale: 100, // 价格精度
            fractional: false, // 分数价格
            has_intraday: true, // 是否具有日内（分钟）历史数据
            has_daily: true, //
            has_no_volume: true, // 是否拥有成交量数据
            has_weekly_and_monthly: true, // 是否具有以W和M为单位的历史数据
            intraday_multipliers: ['1', '5', '15', '30', '60', '1D', '1W', '1M'], // 包含日内周期(分钟单位)的数组
            supported_resolutions: ['1', '5', '15', '30', '60', '1D', '1W', '1M'], // 周期选择器
            currency_code: 'RMB' // 货币代码
        }
    }
}

export default datafeeds

// WEBPACK FOOTER //
// ./src/views/quotation/Datafeeds/index.js
